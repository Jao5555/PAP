# VOID DEFENSE — Documento de Transição / Handoff
**Última atualização:** desta sessão de trabalho, antes de pausa.
**Para quem lê isto:** és uma IA nova (ou uma nova sessão) sem memória da conversa anterior. Este documento existe para te dar TODO o contexto necessário para continuar este projeto sem o João (o utilizador) ter de repetir tudo. Lê isto inteiro antes de tocar em código.

---

## 1. O QUE É ESTE PROJETO

**Void Defense** é um jogo tower defense isométrico 2.5D (Canvas HTML5), feito em JavaScript puro (sem frameworks), com um backend Python opcional para multiplayer e leaderboard.

**Contexto importante:** isto é o **PAP** (Prova de Aptidão Profissional) do João — um projeto final de curso profissional em Portugal (11º/12º ano). Isto significa:
- Vai ser **apresentado/avaliado** — qualidade, robustez e não ter bugs visíveis durante a demo importam muito.
- O João tem prazos reais (não sei quais exatamente — pergunta-lhe).
- Ele está a fazer isto sozinho com ajuda de IA, então explicações claras (não só código) são valiosas — ele parece estar a aprender à medida que o projeto cresce.

**Deployment atual:**
- Repositório GitHub: o jogo está a ser colocado num repo GitHub.
- **URL pública:** `jao5555.github.io/PAP/login.html` (GitHub Pages)
- **Base de dados:** Supabase em `supabase.com/dashboard/project/wwawwsaiibtxwrwdjzbe` — **ainda não integrada no código**. Não tenho a chave `anon`/API key, só o URL do projeto. Pergunta ao João por essa chave antes de tentar integrar Supabase.
- **Servidor multiplayer:** corre localmente no PC do João via `server/server.py` (Python/aiohttp). Para amigos jogarem, precisa de port-forward ou ngrok (documentado em `multiplayer.html`).

---

## 2. ESTRUTURA DE FICHEIROS

```
void-defense-v5/
├── index.html          ← Capa/ecrã inicial (animado, título do jogo)
├── login.html           ← Seleção/criação de perfil (SEM password ainda — ver secção 5)
├── menu.html             ← Menu principal: Jogar / Equipamento / Loja / Manual
├── game.html             ← O JOGO em si (single-player) — canvas + HUD + modais HTML
├── multiplayer.html    ← Lobby de salas coop + leaderboard + jogo coop ao vivo
├── admin.html             ← Painel admin (editar preços, créditos, etc.) — password: Dev_Ori123
├── start_server.bat      ← Launcher Windows: instala aiohttp se preciso, corre server.py
├── css/style.css         ← CSS base partilhado
├── js/
│   ├── config.js          ← TODOS os números de balanceamento (torres, inimigos, ondas, mapas). Fonte da verdade.
│   ├── utils.js             ← Matemática isométrica (U.iso, U.inv, U.diaDist), helpers de desenho
│   ├── particles.js       ← Sistema de partículas (PS) — bursts, texto flutuante, gotas de sangue
│   ├── items.js             ← Sistema de itens de campo (ITEMS) — drops de inimigos, 6 tipos
│   ├── map.js                ← Renderização do mapa isométrico, 4 mapas + tiles especiais (montanha/pedra)
│   ├── codex.js              ← Sistema de conquistas/enciclopédia (CODEX) — 18 entradas, 19+ achievements
│   ├── enemy.js              ← Classe Enemy, 7 tipos (zombie/runner/armored/tank/boss/ninja/voador)
│   ├── tower.js              ← Classe Tower, 11 tipos, renderização com rotação de torreta
│   ├── projectile.js       ← Classe Proj — balas, granadas, dano em área (diamante, não círculo)
│   ├── economy.js          ← Ouro/Energia/Sangue (ECO) — dreno de energia por torre ATIVA vs idle
│   ├── waves.js               ← Sistema de ondas (WV) — 8 ondas, skip, auto-avanço
│   ├── save.js                ← Save/load local (3 slots)
│   ├── profile.js            ← Sistema de perfis locais (PROFILE) — troca de "conta" sem password ainda
│   └── ui.js                    ← Painel direito do jogo (HUD secundário, desenhado no canvas)
└── server/
    ├── server.py              ← Servidor aiohttp: ficheiros estáticos + leaderboard API + WebSocket salas
    ├── simulation.py       ← Motor de jogo AUTORITATIVO para coop (espelha config.js/game.js)
    └── game_data.json    ← Extração automática de config.js para o Python usar os MESMOS números
```

**IMPORTANTE — `game_data.json`:** isto é gerado automaticamente a partir de `config.js` via Node (`vm` module). Se editares valores de balanceamento, edita SEMPRE `js/config.js` primeiro, depois regenera este ficheiro (não editar `game_data.json` à mão — fica dessincronizado do cliente). O comando usado foi algo como:
```js
node -e "var vm=require('vm'),fs=require('fs'); var sb={}; vm.createContext(sb); vm.runInContext(fs.readFileSync('js/config.js','utf8'),sb); fs.writeFileSync('server/game_data.json', JSON.stringify(sb.C,null,2));"
```

---

## 3. O QUE JÁ ESTÁ CONSTRUÍDO E TESTADO

### Single-player (completo e funcional)
- 11 tipos de torre: Pistola, Sniper, L.Granada, Morteiro, Minigun, L.Chamas, Commander, DJ Booth, Gerador, Artilharia (só montanha), Observador (só montanha)
- 7 tipos de inimigo: Zombie, Runner, Z.Blindado, Tank, Boss, Ninja (invisível, só visível perto de Observador), Voador (resiste 45% a dano de área)
- 4 mapas: Deserto, Labirinto, Espiral, Montanha (com tiles elevados exclusivos para Artilharia/Observador)
- 8 ondas com dificuldade crescente
- Economia: Ouro, Energia (com apagão de torres se insuficiente), Sangue (drops de inimigos, gasta-se em Curar Base/Buff Dano/Buff Ataque/Comprar Energia)
- Sistema de itens de campo (drops aleatórios: Núcleo de Energia, Bolsa de Ouro, Sobrecarga, Granada de Gelo, Ogiva Aérea, Kit Médico)
- Codex/Enciclopédia com lore de cada torre/inimigo + 19+ conquistas
- Sistema de perfis locais (múltiplas "contas" no mesmo dispositivo, sem password — ver pendências)
- Save/load (3 slots)
- Upgrade de torres (3 níveis)
- Loja (créditos ganhos em jogo desbloqueiam torres permanentemente)

### Multiplayer Cooperativo (backend testado end-to-end, cliente funcional)
- `server/simulation.py` espelha TODA a lógica do single-player (movimento, targeting, dano em área, invisibilidade do ninja, resistência do voador, economia, ondas) usando os MESMOS números de `game_data.json`
- Testado com ligações WebSocket reais: criar sala, entrar com código, ready-up, jogo autoritativo a correr a 15 ticks/seg, sincronização entre 2 jogadores confirmada (um coloca torre, outro vê aparecer; ondas, mortes, ouro sincronizados)
- Cliente em `multiplayer.html` reconstrói instâncias reais de `Tower`/`Enemy` a partir dos snapshots do servidor e reutiliza o MESMO código de desenho do single-player (`tower.js`/`enemy.js`/`map.js`)

### Multiplayer Competitivo (PvP) — NÃO IMPLEMENTADO
Só existe a infraestrutura de sala (criar sala modo 'pvp', entrar, ready-up). A MECÂNICA de jogo (como funciona "enviar inimigos ao adversário", duas bases separadas, condição de vitória) **não está desenhada nem implementada**. Isto precisa de uma conversa de design com o João antes de começar a codificar — não inventes a mecânica sozinho sem perguntar primeiro.

---

## 4. BUGS CORRIGIDOS NESTA SESSÃO (e como foram testados)

Todos estes foram encontrados através de auditoria de código + testados com harnesses reais (Node `vm`, `jsdom` para DOM real, ligações WebSocket reais contra o servidor a correr). **Não assumas que algo está bugado sem testar primeiro — mas também não assumas que está bem sem testar.**

1. **Clique não funcionava na barra de tropas (só teclas funcionavam)** — causa: `setInterval(updateTroopBar, 100)` destruía e recriava TODOS os elementos DOM a cada 100ms. Se o clique (mousedown→mouseup) calhasse a meio de um destes ciclos, o elemento desaparecia antes do evento `click` disparar. **Corrigido:** separei construção do DOM (só quando o loadout muda) de atualização visual (a cada 100ms, só mexe em texto/classes de elementos já existentes). Testado com jsdom simulando a condição de corrida exata — confirmado que sobrevive agora.

2. **Sistema de upgrade quebrado (o mesmo bug, noutro sítio)** — `syncUpgradeModal()` fazia `body.innerHTML = ...` a cada 100ms, destruindo os botões UPGRADE/VENDER pelo mesmo motivo. **Corrigido** com o mesmo padrão (3 blocos HTML construídos uma vez, só alterna visibilidade). Testado com jsdom da mesma forma.

3. **"Tudo desaparece" / jogo trava e não recupera nem com "retomar"** — causa provável: uma exceção não apanhada dentro do loop principal (`G._loop`) impede a próxima chamada a `requestAnimationFrame`, matando o loop PARA SEMPRE (nada revive um loop morto, incluindo cliques em "retomar"). **Mitigado:** adicionei um `try/catch` à volta de `_update`/`_draw` em `game.js`, que agora mostra o erro no ecrã (mensagem + stack trace) em vez de morrer em silêncio, e continua a tentar o frame seguinte. Testado forçando exceções deliberadas — confirmado que o loop sobrevive.
   ⚠️ **ISTO NÃO É UMA CORREÇÃO DA CAUSA RAIZ** — é uma rede de segurança. A próxima vez que isto acontecer ao João, ele vai ver a mensagem de erro no ecrã e pode tirar print — usa essa informação para encontrar e corrigir a causa real. O João mencionou que acontece "quando começo a colocar várias tropas" — pode ser relacionado com algum limite ou cálculo que rebenta com muitas torres simultâneas (aura entre torres é O(n²), por exemplo — vale a pena olhar para aí primeiro).

4. **Skip de onda apagava TODOS os inimigos** — o João queria que só parasse reforços futuros, mantendo os inimigos já no mapa (têm de ser combatidos normalmente). **Corrigido** em `waves.js` E em `server/simulation.py` (consistência entre single-player e coop). Testado nos dois motores.

5. **Mapa não persistia corretamente ao continuar um save** — `MAP.init(mapKey)` só corria dentro do bloco `if (!fromLoad)` em `game.js`, ou seja, ao continuar uma partida guardada, a grelha do mapa NUNCA era reinicializada para bater com o mapa guardado. Isto explica o bug que o João reportou ("mudei de mapa, o save não bate certo"). **Corrigido:** `MAP.init()` corre sempre agora. Testado isoladamente.

---

## 5. PEDIDOS DO JOÃO — O QUE FALTA FAZER (por prioridade que ele deu)

⚠️ **Lê a mensagem mais recente dele na conversa antes de assumir que esta lista está completa** — isto foi escrito a meio de uma sessão muito longa com MUITOS pedidos acumulados numa mensagem só. Pode haver mais contexto que não coube aqui.

### Alta prioridade (pedidos explícitos, ainda não começados)
1. **Sistema de password + sessão persistente por dispositivo** — já comecei a preparar isto (confirmei que `crypto.subtle.digest('SHA-256', ...)` funciona tanto em browser como Node para testar), mas **não cheguei a implementar**. Plano:
   - Ao criar perfil em `login.html`, campo de password opcional
   - Hash SHA-256 da password (nunca guardar em texto simples no localStorage)
   - Ao fazer login com sucesso, guardar uma "sessão confiada" nesse dispositivo (localStorage) para não pedir password de novo no mesmo browser
   - Opção de "esquecer sessão"/logout por perfil
   - Ver `js/profile.js` — é onde isto deve viver, seguindo o padrão já estabelecido lá

2. **Responsividade mobile/tablet/laptop/PC** — o João disse explicitamente "está meio horrível" no telemóvel. Isto é o maior trabalho pendente. O jogo usa um canvas de tamanho fixo (1280×720) com escala proporcional — funciona mas o layout (painel lateral, barra de tropas) não foi pensado para ecrãs estreitos/portrait. As páginas HTML simples (`menu.html`, `login.html`, `multiplayer.html`, `index.html`) são mais fáceis de tornar responsivas (flexbox/grid + media queries). O `game.html` (canvas do jogo em si) é o mais difícil — precisa de decisão de design: layout alternativo para portrait, ou sugerir landscape no telemóvel, ou repensar a UI para caber em ecrãs pequenos.

3. **Seletor de idioma + menu de configurações** (som, efeitos, etc.) — não existe nada disto ainda. Precisa de um sistema de i18n (strings extraídas para um dicionário PT/EN pelo menos) e uma página/painel de definições novo.

4. **Sons/efeitos sonoros** — o João quer que EU faça isto. **Importante:** não tenho ferramenta de geração de áudio neste ambiente. A abordagem viável é sintetizar efeitos sonoros simples via **Web Audio API** (osciladores/ruído programático — é uma técnica legítima usada em jogos indie, não precisa de ficheiros de áudio externos). Ainda não comecei isto.

5. **Câmara com órbita/zoom** — "ajustar a câmara tipo andar à volta do mapa... da para fazer zoom e outros". Isto é substancial: o motor de render usa uma projeção isométrica FIXA (fórmula `(c-r)*TW/2, (c+r)*TH/2` em `utils.js`). Zoom é relativamente simples (fator de escala). Rotação/órbita around a 4 direções é mais trabalho (jogos isométricos tipicamente suportam rotação em incrementos de 90°, trocando que eixo da grelha mapeia para X/Y no ecrã). Não comecei isto.

6. **Mini-janela "estilo Opera GX"** — já existe uma versão (botão "🗗 MINI-JANELA" em `game.html`, arrastável/redimensionável DENTRO da página). Mas o João parece querer algo mais forte: flutuar por CIMA de outras janelas/apps no ambiente de trabalho, não só dentro do browser. Isto existe como API real no Chrome: **Document Picture-in-Picture API** (`documentPictureInPicture.requestWindow()`) — permite pôr HTML arbitrário (não só `<video>`) numa janela verdadeiramente flutuante ao nível do SO. Vale a pena implementar isto como progressive enhancement (usa a API real se disponível — Chromium só, por agora — com fallback para a versão em-página já existente nos outros browsers).

7. **Login/registo "a sério" ligado a Supabase** — distinto do sistema de perfis locais atual. O João quer guardar dados do utilizador numa base de dados REAL (não só localStorage), para poder aceder ao progresso de dispositivos diferentes. Precisa da API key `anon` do projeto Supabase (só tenho o URL do projeto, não a chave) — pergunta ao João por isso antes de tentar integrar.

8. **Animações/parallax no menu e outras partes do jogo** — o João quer mais movimento/vida visual nas páginas (`index.html`, `menu.html`, e possivelmente outras). Pensa em: camadas de fundo a mexerem-se a velocidades diferentes (parallax) ao fazer scroll ou hover, transições animadas entre ecrãs/abas do menu, hover states mais elaborados nos botões/cards, talvez um fundo animado mais rico na capa (`index.html`). Isto é maioritariamente CSS (`transition`, `@keyframes`, `transform`) nas páginas HTML simples — não precisa de mexer no motor Canvas do jogo em si para isto. **Não foi começado nesta sessão.**

9. **Interface DENTRO do jogo (`game.html`) continua confusa, precisa de mais uma passagem** — ⚠️ nota importante: já houve pelo menos uma sessão de trabalho anterior dedicada especificamente a "limpar" a interface (reduzir ruído visual do mapa — texturas de relva/caminho foram simplificadas — e do HUD — cores foram unificadas, só se usa cor para coisas que realmente precisam de destaque). Mesmo depois disso, o João está a pedir mais uma iteração, o que sugere que o problema não ficou resolvido ou há algo específico que continua a incomodar. **Antes de tentares adivinhar o que está confuso e repetir trabalho já feito sem resolver o problema real, pede ao João exemplos concretos (screenshot + apontar o que especificamente acha confuso).** Áreas possíveis a rever: densidade de informação no painel direito (secções de Ondas/Sangue/Estatísticas empilhadas), a barra de tropas em baixo, o HUD superior, ou simplesmente a quantidade de elementos simultâneos no ecrã durante uma onda com muitas torres/inimigos/partículas/itens ao mesmo tempo.

### Balanceamento — ✅ FEITO nesta sessão (depois do handoff inicial ter sido escrito)
Torres ficaram ~15-20% mais caras, ouro do zombie desceu de 12 para 8. `server/game_data.json` já foi regenerado a partir do `config.js` novo — estão sincronizados. Valores atuais:

| Torre | Custo antigo | Custo novo |
|---|---|---|
| Pistola | $75 | $90 |
| Sniper | $220 | $260 |
| L.Granada | $175 | $210 |
| Morteiro | $310 | $370 |
| Minigun | $340 | $400 |
| L.Chamas | $240 | $290 |
| Commander | $400 | $460 |
| DJ Booth | $370 | $430 |
| Gerador | $280 | $320 |
| Artilharia | $420 | $480 |
| Observador | $260 | $300 |

Ouro base de zombie: 12 → 8. Ouro inicial por dificuldade (`DIFF.startGold`) **não foi tocado** — só custo das torres e ritmo de ganho por kill, para a curva ficar mais lenta sem impedir o arranque do jogo. Se o João continuar a achar que não está bem, a próxima coisa a ajustar é provavelmente `DIFF.startGold` ou o multiplicador `goldM` por dificuldade — não repitas o aumento de custo de torres sem ele pedir explicitamente outra vez.

### Modelos 3D (Meshy.ai)
🔴 **LEMBRETE EXPLÍCITO QUE O JOÃO PEDIU PARA NUNCA SE ESQUECER:** ele só pode fazer **10 downloads por mês** no Meshy.ai. Já tem 10 de 17 modelos planeados (7 inimigos completos + 3 torres: Pistola/Sniper/Minigun). Faltam 7 modelos de torres: **Morteiro, Lança-Chamas, Commander, DJ Booth, Artilharia, Observador, Gerador**. Os prompts para estes já foram dados ao João em mensagens anteriores (procura no histórico da conversa "PRÓXIMO PASSO NÃO FEITO" ou pede-lhe os prompts de volta se precisares). **Nunca sugere ele gastar downloads sem necessidade — lembra-o sempre deste limite antes de qualquer conversa sobre modelos novos.**

Os 10 modelos já recebidos foram descomprimidos/otimizados (decimação de malha, ~279k→~4k triângulos por modelo) e estão em `models/optimized/` — ainda **não integrados no motor de jogo** (o jogo continua a usar formas geométricas Canvas 2.5D, não os modelos GLB reais). Integrar isto é trabalho substancial (provavelmente migrar para Three.js ou similar) que ainda não começou.

---

## 6. FILOSOFIA DE TRABALHO ESTABELECIDA NESTA SESSÃO

O João valoriza **correções pequenas e específicas**, não reescritas completas de ficheiros (ele tem repetido isto). Quando fores mexer em código:
- Edita o mínimo necessário, não reescrevas ficheiros inteiros sem motivo
- **Testa antes de dizeres que algo está corrigido.** Este projeto tem um histórico de bugs subtis (condições de corrida, valores dessincronizados entre ficheiros, etc.) que só apareceram através de testes reais, não inspeção visual do código. Usa:
  - `node -c ficheiro.js` para sintaxe
  - `node` com `vm.createContext()` para testar lógica isolada com stubs
  - `jsdom` (instala via `npm install jsdom` — não persiste entre sessões de terminal, reinstala sempre que precisares) para testar DOM real quando o bug envolve cliques/elementos HTML
  - Para o servidor: corre `server.py` em background (`python3 server.py &`) e testa com `websockets`/`curl` reais — tudo isto tem de acontecer NA MESMA sessão de bash (processos em segundo plano não sobrevivem entre chamadas de ferramentas separadas)
- Quando encontrares um bug ao testar (vais encontrar, aconteceu várias vezes nesta sessão), corrige-o e volta a testar — não assumas que a primeira tentativa resultou.

---

## 7. PRÓXIMOS PASSOS SUGERIDOS (ordem razoável)

1. ~~Aplica o balanceamento de preços~~ — ✅ já feito nesta sessão (ver secção 5).
2. Implementa o sistema de password/sessão em `profile.js` + `login.html` (já tens o design pensado acima)
3. Pergunta ao João pela chave `anon` do Supabase se for avançar com contas reais
4. Decide com o João qual login "vence" — o sistema de perfis locais atual, ou o novo ligado a Supabase, ou os dois coexistem (perfil local = offline, conta Supabase = sincroniza entre dispositivos)?
5. **Antes de mexeres na interface do jogo outra vez (item 9 da lista de pedidos), pede exemplos concretos ao João** — já houve uma passagem de "limpeza visual" nesta sessão e ele ainda acha confuso, por isso adivinhar sem mais informação arrisca repetir trabalho.
6. Ataca a responsividade mobile primeiro nas páginas simples (menu/login/multiplayer/index), depois decide a estratégia para o `game.html`
7. Animações/parallax no menu (item 8) combinam bem com o trabalho de responsividade — se vais mexer no CSS dessas páginas de qualquer forma, vale a pena fazer os dois juntos.
8. Language selector + settings panel podem ser construídos juntos (é natural terem o mesmo painel)
9. Sons via Web Audio API síntese
10. Deixa câmara orbital/zoom e o PvP para o fim — são os maiores e menos urgentes

Boa sorte. O João é um aluno esforçado a construir isto sozinho para o projeto final dele — trata isto com o cuidado que merece.
